<?php 
$con = mysqli_connect('localhost', 'u824022186_apvadmin', '?LcS@4y6Ns4', 'u824022186_apv');
?>