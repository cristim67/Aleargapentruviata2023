<?php

header('Cache-Control: max-age=86400');

?>